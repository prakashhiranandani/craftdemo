# Project Title

Intuit Craft Demo .


## Getting Started


These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

The tool is completely serverless and all API's are deployed in Cloud.


```
 You need to unzip folder and launch index.html that is the starting point.
```


## License

This project is purely for demo purposes.

## Acknowledgments

The project uses the demo firebase application and modifies it to suit the needs of the craft demo.
