/* eslint-disable promise/catch-or-return */
'use strict';

const functions = require('firebase-functions');
let request = require('request');
let jwt = require('jsonwebtoken');
let googlePrivateKey = "not actual key";

const handleMessage = functions.database.instance("intuitassignment").ref('/reciepts/{messageId}/{tagId}')
    .onCreate((snapshot, context) => {
        let original = snapshot.val();
        console.log(original);
        console.log("prakash");
        let additionalClaims = {
            server: true
        };
        let startToken = jwt.sign({uid: context.params.messageId, additionalClaims: additionalClaims},
                    googlePrivateKey, {algorithm: 'RS256'});
                let url = "https://ag79ht7f6k.execute-api.us-east-1.amazonaws.com/test/posttoes";
                console.log(url);
                let options = {
                    method: 'post',
                    body: original,
                    json: true,
                    url: url,
                    headers: {
                        'uid': context.params.messageId,
                        'idtoken': startToken,
                        'Content-Type': 'application/json'
                    }
                };
                request(options, (error, response, body) => {
                    console.log('error:', error);
                    console.log('statusCode:', response && response.statusCode);
                    console.log('body:', body);
                });

        return null;
});

module.exports = {handleMessage:handleMessage};
