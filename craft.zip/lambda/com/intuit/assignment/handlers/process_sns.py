import json
import importlib
import os
from com.intuit.assignment.common.assignment_exception import AssignmentException
from com.intuit.assignment.common.assignment_logging import Logger
from com.intuit.assignment.common.database_utility  import DBUtility
from json import dumps as json_dumps
from json import loads as json_loads
import base64
import boto3


__author__  = "Prakash Hiranandani"
__version__ = "1.0"






logger = Logger.get_logger("Assignment Interceptor")

def process_request(event, context):
    try:
        records=event.get("Records")
        sns=records[0].get("Sns").get("Message")
        message = json_loads(sns)
        deviceId= message.get("deviceId")
        etype = message.get("type")
        userId= message.get("userId")
        campaignId = message.get("campaignId")
        time = message.get("time")

        if etype == 'impression':
            query = "insert into impressions (userid,deviceid,imptime,campaign_id) values (%s,%s,%s,%s) "
        elif etype == 'click':
            query = "insert into clicks (userid,deviceid,clicktime,campaign_id) values (%s,%s,%s,%s) "
        else :
            query = "select id from impressions where deviceid='" +deviceId+ "' order by imptime desc limit 1"
            records = DBUtility.get_records(query)
            records = json_loads(records)
            impId=None
            for record in records:
                impId=record.get("id")
                
            query = "select id from clicks where deviceid='" +deviceId+ "' order by clicktime desc limit 1"
            clickId=None
            records =DBUtility.get_records(query)
            records = json_loads(records)
            for record in records:
                clickId=record.get("id")
            query = "insert into installs (userid,deviceid,installtime,campaign_id,impression_id,click_id) values (%s,%s,%s,%s,%s,%s) "
            id = DBUtility.insert_record(query,(userId,deviceId,time,campaignId,impId,clickId))
            return id
        
        id = DBUtility.insert_record(query,(userId,deviceId,time,campaignId))
        return id

    except Exception as ex:
        return AssignmentException.raise_exception(ex)


        print(custom_token)
