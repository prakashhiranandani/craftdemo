import json
import os
import boto3
import hashlib 
from com.intuit.assignment.common.assignment_exception import AssignmentException
from com.intuit.assignment.common.assignment_logging import Logger
from com.intuit.assignment.service.assignment_service import AssignmentService
from com.intuit.assignment.utils.proxy_response import get_response
from com.intuit.assignment.common.assignment_custom_exception import AssignmentCustomException
from com.intuit.assignment.common.assignment_custom_exception import AssignmentCustomException
import uuid
from com.intuit.assignment.utils import firebase_helper

from com.intuit.assignment.common.database_utility  import DBUtility
from com.intuit.assignment.common.kms  import KMS
from json import loads as json_loads
logger = Logger.get_logger('Assignment Handler')
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

import time



def posttoes(event, context):
    """Authenticated API to post to es

    Args:
        event (Lambda Event) : 
        context (Lambda Context): Lambda context

    Returns:
        proxy_response: The response object for result of execution


    """
    try:
        logger.debug("Event is %s" % event)
        body = event.get("body")
        
        bodyJson = json.loads(body)
        
        uid = bodyJson.get("uid")
        bodyJson["timestamp"] = int(round(time.time() * 1000))
        bodyJson["user"] = uid
        uid = str(uuid.uuid4())
        bodyJson["uid"] = uid
        body = json.dumps(bodyJson)
        session = boto3.session.Session()
        credentials = session.get_credentials()
        awsauth = AWS4Auth(credentials.access_key,
                       credentials.secret_key,
                       session.region_name, 'es',
                       session_token=credentials.token)
        es_url = "https://search-intuitassignment-lyrs6bylhk3vzqxg23d3whn7yi.us-east-1.es.amazonaws.com"
        es = Elasticsearch(
            es_url,
            http_auth=awsauth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection
        )
        timestamp=int(round(time.time() * 1000))
        es.index(index='reciepts', doc_type='message',id=uid, body=body)
        query = "select id from users where display_name='" + bodyJson.get("user") + "'"
        records =DBUtility.get_records(query)
        records = json_loads(records) 
        query="insert into reciepts (user_id,body,merchant,title,amount) values (%s,%s,%s,%s,%s)"
        records=DBUtility.insert_record(query,(records[0].get("id"),bodyJson.get("body"),bodyJson.get("merchant"),bodyJson.get("title"),bodyJson.get("amount") ))
        return get_response(200, {})
    except Exception as ex:
        return AssignmentException.raise_exception(ex)
      
        
    
        
def authenticate(event, context):
    """Authenticated API to return firebase token

    Args:
        event (Lambda Event) : 
        context (Lambda Context): Lambda context

    Returns:
        proxy_response: The response object for impression


    """
    try:
        logger.debug("Event is %s" % event)
        body = event.get("body")
        body = json.loads(body)
        password=body.get("password")
        password = hashlib.md5(password.encode()) 
        query = "select * from users where email='" + body.get("user") + "' AND password='" + password.hexdigest()+ "'" 
        records =DBUtility.get_records(query)
        records = json_loads(records)
        
        if not records: 
            return get_response(401,{'Error':'Unauthorized'})
        uid = records[0].get("guid")
        email = records[0].get("email")
        photo_url = records[0].get("photo_url")
        custom_token = {"uid": uid, "role": "customer"}
        custom_token = firebase_helper.create_custom_token(uid, custom_token,None,email,uid,photo_url)
        custom_token = custom_token.decode("utf-8")  
        return get_response(200, {'token': custom_token})
    except Exception as ex:
        return AssignmentException.raise_exception(ex)
      
        
def register(event, context):
    """Authenticated API to return firebase token

    Args:
        event (Lambda Event) : 
        context (Lambda Context): Lambda context

    Returns:
        proxy_response: The response object for impression


    """
    try:
        logger.debug("Event is %s" % event)
        body = event.get("body")
        body = json.loads(body)
        password=body.get("password")
        password = hashlib.md5(password.encode())
        password=password.hexdigest()       
        uuid.uuid4()
        guid = str(uuid.uuid4())        
        query="insert into  users (display_name,email,password,guid,photo_url) values (%s,%s,%s,%s,%s)"
        try:
           records=DBUtility.insert_record(query,(body.get("name"), body.get("email"),password,guid,'https://s3.amazonaws.com/craftdemosample/avatar.jpg'))
        except Exception as ex:
           return get_response(409,{})
        return get_response(200, {})
    except Exception as ex:
        return AssignmentException.raise_exception(ex)
      
        

