import json
import importlib
import os
from com.intuit.assignment.common.assignment_exception import AssignmentException
from com.intuit.assignment.common.assignment_logging import Logger
from json import dumps as json_dumps
from json import loads as json_loads
import base64


__author__  = "Prakash Hiranandani"
__version__ = "1.0"




mapping = {
    #The mapping will have handler to be invoked
    #These can be handled accordingly in the process_request function.
    #"/assignment/impressionGet: {"method":"get" , {"handler":"com.intuit.assignment.handlers.v1.assignment","apiKeyValidate":"true","tokenValidate":"false"}}
    # POST/GET will be invoked based on the method.
    "/authentication": {"handler": "com.intuit.assignment.handlers.v1.assignment","post": {"methodName": "authenticate", "apiKeyValidate": "true","tokenValidate": "false"}},
    "/register": {"handler": "com.intuit.assignment.handlers.v1.assignment","post": {"methodName": "register", "apiKeyValidate": "true","tokenValidate": "false"}},
    "/posttoes": {"handler": "com.intuit.assignment.handlers.v1.assignment","post": {"methodName": "posttoes", "apiKeyValidate": "true","tokenValidate": "false"}}
}

logger = Logger.get_logger("Assignment Interceptor")

def process_request(event, context):
    try:
        resource = event.get("resource")
        method = event.get("httpMethod")
        logger.info("The path is %s" % resource)
        function_ref = getattr(importlib.import_module(mapping[resource]["handler"]), mapping[resource][method.lower()]["methodName"])
        return function_ref(event, context)
    except Exception as ex:
        return AssignmentException.raise_exception(ex)


