import firebase_admin
from firebase_admin import auth
from firebase_admin.auth import AuthError
from firebase_admin import credentials
from firebase_admin import db
import json

_cur_account_key_json = {} 
 
_cur_database_url = None
cred = credentials.Certificate(_cur_account_key_json)
_cur_app = firebase_admin.initialize_app(cred, {'databaseURL': _cur_database_url})

def create_custom_token(uid, developer_claims=None, app=None,email=None,display_name=None,photo_url=None):
    try:
        user=auth.get_user(uid=uid)
    except AuthError:
        auth.create_user(uid=uid,email=email,display_name=display_name,photo_url=photo_url)
    return auth.create_custom_token(uid, developer_claims, app)


def delete_user(uid, app=None):
    auth.delete_user(uid, app)


def reference(path, app=None):
    return db.reference(path, app)



