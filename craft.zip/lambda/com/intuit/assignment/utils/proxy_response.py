import json


class Response(object):
    def __init__(self, status_code=204, body="", headers=None):
        self.status_code = status_code
        self.body = body
        self.headers = dict({
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,X-Api-Key",
            "Access-Control-Allow-Credentials": True,
            "Content-Type": "application/json"
          })
        if headers is not None and headers.get("Location")is not None:
            self.headers["Location"] = headers["Location"]
        if headers is not None and headers.get("Content-Type") is not None:
            self.headers["Content-Type"] = headers["Content-Type"]

    def get_response(self):
        # don"t return a body for 204 responses
        if self.status_code is not 204:
            return {
                "statusCode": self.status_code,
                "body": self.body,
                "headers": self.headers
            }
        return {
            "statusCode": 204
        }


def get_response(status_code=204, body=None, header=None):
    if type(body) is dict:
        body = json.dumps(body)
    return Response(status_code=status_code, body=body, headers=header).get_response()
