from com.intuit.assignment.common.assignment_logging import Logger

logger = Logger.get_logger("Assignment Custom Exception")


class AssignmentCustomException(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

