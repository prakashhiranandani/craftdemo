import boto3
import base64

class KMS:
    @staticmethod
    def encrypt_data(key_id, plaintext_message,region='us-east-1'):
        session = boto3.session.Session(region_name=region)

        kms = session.client('kms')

        stuff = kms.encrypt(KeyId=key_id, Plaintext=plaintext_message)
        binary_encrypted = stuff[u'CiphertextBlob']
        encrypted_password = base64.b64encode(binary_encrypted)
        return encrypted_password.decode()



    @staticmethod
    def decrypt_data(encrypted_password,region='us-east-1'):
        session = boto3.session.Session(region_name=region)
        kms = session.client('kms')
        binary_data = base64.b64decode(encrypted_password)
        meta = kms.decrypt(CiphertextBlob=binary_data)
        plaintext = meta[u'Plaintext']
        return plaintext.decode()
