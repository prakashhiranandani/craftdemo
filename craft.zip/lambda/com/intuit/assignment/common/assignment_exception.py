import json
import traceback
from com.intuit.assignment.common.assignment_logging import Logger
from com.intuit.assignment.utils.proxy_response import get_response

logger = Logger.get_logger("Assignment Exception")


class AssignmentException(object):
    @staticmethod
    def raise_exception(exception):
        try:
            raise exception
        except:
            stacktrace = traceback.format_exc()

        if stacktrace is not None:
            logger.error(stacktrace)

        body = json.dumps({
            'isError': True,
            'type': 'Error',
            'message': str(exception)
        })
        headers = {"test":"test" }

        return get_response(503, body, headers)
