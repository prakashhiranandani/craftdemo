from datetime import datetime
from json import JSONEncoder as json_JSONEncoder


class DateTimeEncoder(json_JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()

        return json_JSONEncoder.default(self, o)
