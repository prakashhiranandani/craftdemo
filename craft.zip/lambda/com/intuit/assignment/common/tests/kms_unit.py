import unittest
from com.intuit.assignment.common.kms  import KMS

class TestKms(unittest.TestCase):

    def test_encrypt(self):
        res = KMS.decrypt_data("AQICAHh+nSpXCrFbopnJXbAZMBZYaFc0bkWgMukMlv6G1rT3jgF2nk9xhu0iea3u+a1/4lCyAAAAYzBhBgkqhkiG9w0BBwagVDBSAgEAME0GCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMn2Hz5XBwocty7E2lAgEQgCAF1dKbYUb9Y+dR6YYKlcgH3YK3SLRZAdTjJ0ueTJJCCA==")
        self.assertEqual(res, "hello")


if __name__ == '__main__':
    unittest.main()
