import MySQLdb
import json
import traceback
import datetime
import os
import base64
from com.intuit.assignment.common.kms  import KMS


host = os.environ.get("db_host")
user = os.environ.get("db_user")
passwd = os.environ.get("db_passwd")
passwd = KMS.decrypt_data(passwd)
name = os.environ.get("db_name")

connection = MySQLdb.connect(host=host,user=user,passwd=passwd,db=name)
 
def datetime_handler(x):
    if isinstance(x, datetime.datetime):
        return x.isoformat()
    raise TypeError("Unknown type")

class DBUtility:
    
   
    @staticmethod
    def get_records(query):
        try:
            global connection
            if (connection):
                print ("Connection successful")
            else:
                connection = MySQLdb.connect(host=host,user=user,passwd=passwd,db=name)
            cursor = connection.cursor()
            cursor.execute(query)
            names = [description[0] for description in cursor.description]
            results = []
            for row in cursor.fetchall():
                  results.append(dict(zip(names, row)))

            results = json.dumps(results, default=datetime_handler)
            return results
        except Exception as ex:
            print(ex)
            raise ex

    @staticmethod
    def insert_record(query,tuple):
        try:
            global connection
            if (connection):
                print ("Connection successful")
            else:
                connection = MySQLdb.connect(host=host,user=user,passwd=passwd,db=name)
            cursor = connection.cursor()
            cursor.execute(query,tuple)
            connection.commit()
            id = cursor.lastrowid
            print('Record inserted successfully')
            return id
        except Exception as ex:
            print(ex)
            raise ex

    @staticmethod
    def update_record(query,tuple):
        try:
            global connection
            if (connection):
                print ("Connection successful")
            else:
                connection = MySQLdb.connect(host=host,user=user,passwd=passwd,db=name)
            cursor = connection.cursor()
            cursor.execute(query,tuple)
            connection.commit()
            records_updated = cursor.rowcount
            print('Record updated successfully')
            return records_updated
        except Exception as ex:
            print(ex)
            raise ex

