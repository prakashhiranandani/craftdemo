import datetime
import os
import traceback
from enum import Enum


class LogLevel(Enum):
    ALL = 0
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERROR = 4

class DBLog(Enum):
    ON = True
    OFF = False


# This is the log level and will be driven from Environment variable.
# Can be changed using AWS CLI by updating the env variable.
ENV_LOG_LEVEL = LogLevel[os.environ.get("LOG_LEVEL", LogLevel.INFO.name)]

# This can be used to print the SQL statements used. By default this will be set to FALSE
# Where ever we want to print the SQL's use, Logger.dblog
ENV_DB_LOG = DBLog[os.environ.get("DB_LOG", DBLog.OFF.name)]


class Logger(object):
    def __init__(self, name, log_level_=None):
        self.name = name
        self.log_level = log_level_ or ENV_LOG_LEVEL

    def get_log_level(self):
        return self.log_level

    def set_log_level(self, log_level):
        """
        :param log_level: value to set for logging
        :raises KeyError: if log_level cannot be parsed
        :param log_level: str, int or LogLevel representing a LogLevel
        """
        if type(log_level) is LogLevel:
            self.log_level = log_level
        elif type(log_level) is str:
            self.log_level = LogLevel[log_level]
        elif type(log_level) is int:
            try:
                self.log_level = LogLevel(log_level)
            except ValueError as e:
                raise KeyError('Invalid LogLevel: {}, error: {}'.format(log_level, e))

        else:
            raise KeyError('Invalid type used to attempt to set log level, supported types are LogLevel, str or int')

    def debug(self, msg):
        if self.log_level.value <= LogLevel.DEBUG.value:
            print("({}) {}:{}: {}".format(datetime.datetime.now(), self.name, "DEBUG", msg))

    def info(self, msg):
        if self.log_level.value <= LogLevel.INFO.value:
            print("({}) {}:{}: {}".format(datetime.datetime.now(), self.name, "INFO", msg))

    def warn(self, msg):
        if self.log_level.value <= LogLevel.WARN.value:
            print("({}) {}:{}: {}".format(datetime.datetime.now(), self.name, "WARN", msg))

    def error(self, msg):
        if self.log_level.value <= LogLevel.ERROR.value:
            print("({}) {}:{}: {}".format(datetime.datetime.now(), self.name, "ERROR", msg))

    def dblog(self, msg):
        if ENV_DB_LOG.value:
            print("({}) {}:{}: {}".format(datetime.datetime.now(), self.name, "SQL", msg))

    def error_exception(self, msg, exception):
        """
        :param msg:
        :param exception:
        :return:
        """
        print("({}) {}: {}".format(datetime.datetime.now(), self.name, msg))
        if exception is not None:
            traceback.print_tb(exception.__traceback__)
            print(exception)

    def log(self, msg):
        print("({}) {}: {}".format(datetime.datetime.now(), self.name, msg))

    @staticmethod
    def get_logger(name, log_level_=None):
        return Logger(name, log_level_=log_level_)


def get_logger(name, log_level_=None):
    return Logger(name, log_level_=log_level_)
