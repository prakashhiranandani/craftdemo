import json
from com.intuit.assignment.common.assignment_logging import Logger

logger = Logger.get_logger('Assignment Service')

class AssignmentService(object):
    def get_dummy_payload(self, payload):
        success = "true"
        logger.info("The assignemnt service is %s" % success)
        return {"success": success}

