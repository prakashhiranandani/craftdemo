/**
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';


// Shortcuts to DOM Elements.
var messageForm = document.getElementById('message-form');
var messageInput = document.getElementById('new-reciept-desc');
var titleInput = document.getElementById('new-reciept-title');

var merchantInput = document.getElementById('new-reciept-merchant');
var valueInput = document.getElementById('new-reciept-value');
var signInButton = document.getElementById('sign-in-button');
var hideInButton = document.getElementById('hideloginform');
var registerButton = document.getElementById('registerbutton');
var signOutButton = document.getElementById('sign-out-button');
var splashPage = document.getElementById('page-splash');
var addReciept = document.getElementById('add-reciept');
var addButton = document.getElementById('add');
var recentRecieptsSection = document.getElementById('recent-reciepts-list');
var userRecieptsSection = document.getElementById('user-reciepts-list');
var topUserRecieptsSection = document.getElementById('top-user-reciepts-list');
var myRecieptsMenuButton = document.getElementById('menu-my-reciepts');
var listeningFirebaseRefs = [];

/**
 * Saves a new reciept to the Firebase DB.
 */
// [START write_fan_out]
function writeNewReciept(uid, username, picture, title, body,merchant,amount) {
  // A reciept entry.
  var recieptData = {
    author: username,
    uid: uid,
    body: body,
    title: title,
    starCount: 0,
    authorPic: picture,
    merchant: merchant,
    amount: amount
  };

  // Get a key for a new Reciept.
  var newRecieptKey = firebase.database().ref().child('reciepts/'+ uid).push().key;
  // Write the new reciept's data simultaneously in the posts list and the user's post list.
  var updates = {};
  updates['/reciepts/'+ uid ] = recieptData;
  //updates['/user-reciepts/' + uid + '/' + newRecieptKey] = postData;
  firebase.database().ref('/user-reciepts/'+ uid).push(recieptData);
  return firebase.database().ref('/reciepts/'+ uid).push(recieptData);
}
// [END write_fan_out]

/**
 * Star/unstar reciept.
 */
// [START reciept_stars_transaction]
function toggleStar(recieptRef, uid) {
  recieptRef.transaction(function(post) {
    if (reciept) {
      if (reciept.stars && post.stars[uid]) {
        reciept.starCount--;
        reciept.stars[uid] = null;
      } else {
        reciept.starCount++;
        if (!reciept.stars) {
          reciept.stars = {};
        }
        reciept.stars[uid] = true;
      }
    }
    return reciept;
  });
}
// [END reciept_stars_transaction]

/**
 * Creates a reciept element.
 */
function createRecieptElement(recieptId, title, text, author, authorId, authorPic,amount,merchant) {
  var uid = firebase.auth().currentUser.uid;

  var html =
      '<div class="reciept post-' + recieptId + ' mdl-cell mdl-cell--12-col ' +
                  'mdl-cell--6-col-tablet mdl-cell--4-col-desktop mdl-grid mdl-grid--no-spacing">' +
        '<div class="mdl-card mdl-shadow--2dp">' +
          '<div class="mdl-card__title mdl-color--light-blue-600 mdl-color-text--white">' +
            '<h4 class="mdl-card__title-text"></h4>' +
          '</div>' +
          '<div class="header">' +
            '<div>' +
              '<div class="avatar"></div>' +
              '<div class="username mdl-color-text--black"></div>' +
            '</div>' +
          '</div>' +
          '<span class="star">' +
            '<div class="not-starred material-icons">star_border</div>' +
            '<div class="starred material-icons">star</div>' +
            '<div class="star-count">0</div>' +
          '</span>' +
          '<div class="text"></div>' +
          '<div class="text"></div>' +
          '<div class="text"></div>' +
          '<div class="comments-container"></div>' +
          '<form class="add-comment" action="#">' +
            '<div class="mdl-textfield mdl-js-textfield">' +
            '</div>' +
          '</form>' +

        '</div>' +
      '</div>';

  // Create the DOM element from the HTML.
  var div = document.createElement('div');
  div.innerHTML = html;
  var recieptElement = div.firstChild;
  /*if (componentHandler) {
    componentHandler.upgradeElements(recieptElement.getElementsByClassName('mdl-textfield')[0]);
  }*/

  //var addCommentForm = recieptElement.getElementsByClassName('add-comment')[0];
  //var commentInput = recieptElement.getElementsByClassName('new-comment')[0];
  var star = recieptElement.getElementsByClassName('starred')[0];
  var unStar = recieptElement.getElementsByClassName('not-starred')[0];

  // Set values.
  recieptElement.getElementsByClassName('text')[0].innerText = text;
  recieptElement.getElementsByClassName('text')[1].innerText = amount;
  recieptElement.getElementsByClassName('text')[2].innerText = merchant;
  recieptElement.getElementsByClassName('mdl-card__title-text')[0].innerText = title;
  recieptElement.getElementsByClassName('username')[0].innerText = author || 'Anonymous';
  recieptElement.getElementsByClassName('avatar')[0].style.backgroundImage = 'url("' +
      (authorPic || './silhouette.jpg') + '")';

  // Listen for comments.
  // [START child_event_listener_recycler]
  var commentsRef = firebase.database().ref('reciept-comments/' + recieptId);
  commentsRef.on('child_added', function(data) {
    addCommentElement(recieptElement, data.key, data.val().text, data.val().author);
  });

  commentsRef.on('child_changed', function(data) {
    setCommentValues(recieptElement, data.key, data.val().text, data.val().author);
  });

  commentsRef.on('child_removed', function(data) {
    deleteComment(recieptElement, data.key);
  });
  // [END child_event_listener_recycler]

  // Listen for likes counts.
  // [START reciept_value_event_listener]
  var starCountRef = firebase.database().ref('reciepts/' + recieptId + '/starCount');
  starCountRef.on('value', function(snapshot) {
    updateStarCount(recieptElement, snapshot.val());
  });
  // [END reciept_value_event_listener]

  // Listen for the starred status.
  var starredStatusRef = firebase.database().ref('reciepts/' + recieptId + '/stars/' + uid);
  starredStatusRef.on('value', function(snapshot) {
    updateStarredByCurrentUser(recieptElement, snapshot.val());
  });

  // Keep track of all Firebase reference on which we are listening.
  listeningFirebaseRefs.push(commentsRef);
  listeningFirebaseRefs.push(starCountRef);
  listeningFirebaseRefs.push(starredStatusRef);

  // Create new comment.
  /*addCommentForm.onsubmit = function(e) {
    e.preventDefault();
    createNewComment(recieptId, firebase.auth().currentUser.displayName, uid, commentInput.value);
    commentInput.value = '';
    commentInput.parentElement.MaterialTextfield.boundUpdateClassesHandler();
  };*/

  // Bind starring action.
  var onStarClicked = function() {
    var globalRecieptRef = firebase.database().ref('/reciepts/' + postId);
    var userRecieptRef = firebase.database().ref('/user-reciepts/' + authorId + '/' + postId);
    toggleStar(globalRecieptRef, uid);
    toggleStar(userRecieptRef, uid);
  };
  unStar.onclick = onStarClicked;
  star.onclick = onStarClicked;

  return recieptElement;
}

/**
 * Writes a new comment for the given reciept.
 */
function createNewComment(recieptId, username, uid, text) {
  firebase.database().ref('reciept-comments/' + postId).push({
    text: text,
    author: username,
    uid: uid
  });
}

/**
 * Updates the starred status of the reciept.
 */
function updateStarredByCurrentUser(recieptElement, starred) {
  if (starred) {
    recieptElement.getElementsByClassName('starred')[0].style.display = 'inline-block';
    recieptElement.getElementsByClassName('not-starred')[0].style.display = 'none';
  } else {
    recieptElement.getElementsByClassName('starred')[0].style.display = 'none';
    recieptElement.getElementsByClassName('not-starred')[0].style.display = 'inline-block';
  }
}

/**
 * Updates the number of stars displayed for a reciept.
 */
function updateStarCount(recieptElement, nbStart) {
  recieptElement.getElementsByClassName('star-count')[0].innerText = nbStart;
}

/**
 * Creates a comment element and adds it to the given recieptElement.
 */
function addCommentElement(recieptElement, id, text, author) {
  var comment = document.createElement('div');
  comment.classList.add('comment-' + id);
  comment.innerHTML = '<span class="username"></span><span class="comment"></span>';
  comment.getElementsByClassName('comment')[0].innerText = text;
  comment.getElementsByClassName('username')[0].innerText = author || 'Anonymous';

  var commentsContainer = recieptElement.getElementsByClassName('comments-container')[0];
  commentsContainer.appendChild(comment);
}

/**
 * Sets the comment's values in the given recieptElement.
 */
function setCommentValues(recieptElement, id, text, author) {
  var comment = recieptElement.getElementsByClassName('comment-' + id)[0];
  comment.getElementsByClassName('comment')[0].innerText = text;
  comment.getElementsByClassName('fp-username')[0].innerText = author;
}

/**
 * Deletes the comment of the given ID in the given recieptElement.
 */
function deleteComment(recieptElement, id) {
  var comment = recieptElement.getElementsByClassName('comment-' + id)[0];
  comment.parentElement.removeChild(comment);
}

/**
 * Starts listening for new reciepts and populates posts lists.
 */
function startDatabaseQueries() {
  // [START my_top_reciepts_query]
  var myUserId = firebase.auth().currentUser.uid;
  var topUserRecieptsRef = firebase.database().ref('user-reciepts/' + myUserId).orderByChild('starCount');
  // [END my_top_reciepts_query]
  // [START recent_reciepts_query]
  var recentRecieptsRef = firebase.database().ref('reciepts').limitToLast(100);
  // [END recent_reciepts_query]
  var userRecieptsRef = firebase.database().ref('user-reciepts/' + myUserId);

  var fetchReciepts = function(recieptsRef, sectionElement) {
    recieptsRef.on('child_added', function(data) {
      var author = data.val().author || 'Anonymous';
      var containerElement = sectionElement.getElementsByClassName('reciepts-container')[0];
      containerElement.insertBefore(
        createRecieptElement(data.key, data.val().title, data.val().body, author, data.val().uid, data.val().authorPic,data.val().amount,data.val().merchant),
        containerElement.firstChild);
    });
    recieptsRef.on('child_changed', function(data) {
      var containerElement = sectionElement.getElementsByClassName('reciepts-container')[0];
      var recieptElement = containerElement.getElementsByClassName('post-' + data.key)[0];
      recieptElement.getElementsByClassName('mdl-card__title-text')[0].innerText = data.val().title;
      recieptElement.getElementsByClassName('username')[0].innerText = data.val().author;
      recieptElement.getElementsByClassName('text')[0].innerText = data.val().body;
      recieptElement.getElementsByClassName('text')[0].innerText = data.val().merchant;
      recieptElement.getElementsByClassName('text')[0].innerText = data.val().amount;
      recieptElement.getElementsByClassName('star-count')[0].innerText = data.val().starCount;
    });
    recieptsRef.on('child_removed', function(data) {
      var containerElement = sectionElement.getElementsByClassName('reciepts-container')[0];
      var reciept = containerElement.getElementsByClassName('post-' + data.key)[0];
      reciept.parentElement.removeChild(post);
    });
  };

  // Fetching and displaying all reciepts of each sections.
  fetchReciepts(topUserRecieptsRef, topUserRecieptsSection);
  fetchReciepts(recentRecieptsRef, recentRecieptsSection);
  fetchReciepts(userRecieptsRef, userRecieptsSection);

  // Keep track of all Firebase refs we are listening to.
  listeningFirebaseRefs.push(topUserRecieptsRef);
  listeningFirebaseRefs.push(recentRecieptsRef);
  listeningFirebaseRefs.push(userRecieptsRef);
}

/**
 * Writes the user's data to the database.
 */
// [START basic_write]
function writeUserData(userId, name, email, imageUrl) {
  firebase.database().ref('users/' + userId).set({
    username: name,
    email: email,
    profile_picture : imageUrl
  });
}
// [END basic_write]

/**
 * Cleanups the UI and removes all Firebase listeners.
 */
function cleanupUi() {
  // Remove all previously displayed reciepts.
  topUserRecieptsSection.getElementsByClassName('reciepts-container')[0].innerHTML = '';
  recentRecieptsSection.getElementsByClassName('reciepts-container')[0].innerHTML = '';
  userRecieptsSection.getElementsByClassName('reciepts-container')[0].innerHTML = '';

  // Stop all currently listening Firebase listeners.
  listeningFirebaseRefs.forEach(function(ref) {
    ref.off();
  });
  listeningFirebaseRefs = [];
}

/**
 * The ID of the currently signed-in User. We keep track of this to detect Auth state change events that are just
 * programmatic token refresh but not a User status change.
 */
var currentUID;

/**
 * Triggers every time there is a change in the Firebase auth state (i.e. user signed-in or user signed out).
 */
function onAuthStateChanged(user) {
  // We ignore token refresh events.
  if (user && currentUID === user.uid) {
    return;
  }

  cleanupUi();
  if (user) {
    currentUID = user.uid;
    splashPage.style.display = 'none';
    writeUserData(user.uid, user.displayName, user.email, user.photoURL);
    startDatabaseQueries();
  } else {
    // Set currentUID to null.
    currentUID = null;
    // Display the splash page where you can sign-in.
    splashPage.style.display = '';
  }
}

/**
 * Creates a new reciept for the current user.
 */
function newRecieptForCurrentUser(title, text,merchant,amount) {
  // [START single_value_read]
  var userId = firebase.auth().currentUser.uid;
  return firebase.database().ref('/users/' + userId).once('value').then(function(snapshot) {
    var username = (snapshot.val() && snapshot.val().username) || 'Anonymous';
    // [START_EXCLUDE]
    return writeNewReciept(firebase.auth().currentUser.uid, firebase.auth().currentUser.email,
      firebase.auth().currentUser.photoURL,
      title, text,merchant,amount);
    // [END_EXCLUDE]
  });
  // [END single_value_read]
}

/**
 * Displays the given section element and changes styling of the given button.
 */
function showSection(sectionElement, buttonElement) {
  recentRecieptsSection.style.display = 'none';
  userRecieptsSection.style.display = 'none';
  topUserRecieptsSection.style.display = 'none';
  addReciept.style.display = 'none';
  //myRecieptsMenuButton.classList.remove('is-active');

  if (sectionElement) {
    sectionElement.style.display = 'block';
  }
  if (buttonElement) {
    buttonElement.classList.add('is-active');
  }
}

// Bindings on load.
window.addEventListener('load', function() {
  // Bind Sign in button.

   
    registerButton.addEventListener('click', function() {
        var name = document.getElementById('name');
        var email = document.getElementById('email');
        
        var userPassword = document.getElementById('passwordreg');

        var provider = new firebase.auth.GoogleAuthProvider();
        $.ajax({
          "async": true,
          "crossDomain": true,
          "contentType": "application/json; charset=utf-8",
          "dataType": "json",
          "data": JSON.stringify({
            "email": email.value,
            "name": name.value,
            "password": userPassword.value
          }),
          "url": "https://ag79ht7f6k.execute-api.us-east-1.amazonaws.com/test/register",
          "method": "POST",
          "headers": {
            "content-type": "application/json"
          },
          "statusCode": {
            "409": function() {
                alert( "User already registered!!!!" );
            }
           }
        }).then(function(response, status, xhr) {   
             var displaySignIn = document.getElementById("registerinform");
             displaySignIn.style.display = "none";
             displaySignIn = document.getElementById("signinform");
             displaySignIn.style.display = "block";
             displaySignIn = document.getElementById("registrationtext");
             displaySignIn.style.display = "block";
        });

  });


  signInButton.addEventListener('click', function() {
    var userName = document.getElementById('username');
    
    var userPassword = document.getElementById('password');

    var provider = new firebase.auth.GoogleAuthProvider();
    $.ajax({
      "async": true,
      "crossDomain": true,
      "contentType": "application/json; charset=utf-8",
      "dataType": "json",
      "data": JSON.stringify({
        "user": userName.value,
        "password": userPassword.value
      }),
      "url": "https://ag79ht7f6k.execute-api.us-east-1.amazonaws.com/test/authentication",
      "method": "POST",
      "headers": {
        "content-type": "application/json"
      },
      "statusCode": {
        "401": function() {
            alert( "Not Authorized to perfrom operation" );
        }
       }
    }).then(function(response, status, xhr) {
      var statusCode = xhr.status;  
      var token = response.token;
      //window.friendlyChat.agentName = response.UserName;
      firebase.auth().signInWithCustomToken(token);

    });

    //firebase.auth().signInWithPopup(provider);
  });
  hideInButton.addEventListener('click', function() {
    var displaySignIn = document.getElementById("signinform"); 
    displaySignIn.style.display = "none";
    
    displaySignIn = document.getElementById("registerinform"); 
    displaySignIn.style.display = "block";
  });


  // Bind Sign out button.
  signOutButton.addEventListener('click', function() {
    firebase.auth().signOut();
  });

  // Listen for auth state changes
  firebase.auth().onAuthStateChanged(onAuthStateChanged);

  // Saves message on form submit.
  messageForm.onsubmit = function(e) {
    e.preventDefault();
    var text = messageInput.value;
    var title = titleInput.value;
    
    var merchant = merchantInput.value;
    var amount = valueInput.value;
    if (text && title) {
      newRecieptForCurrentUser(title, text,merchant,amount).then(function() {
        myRecieptsMenuButton.click();
      });
      messageInput.value = '';
      titleInput.value = '';
    
      merchantInput.value = '';
      valueInput.value='';;
      titleInput.value = '';
    }
  };

  // Bind menu buttons.
  
  myRecieptsMenuButton.onclick = function() {
    showSection(userRecieptsSection, myRecieptsMenuButton);
  };
  addButton.onclick = function() {
    showSection(addReciept);
    messageInput.value = '';
    titleInput.value = '';
    merchantInput.value = '';
    valueInput.value = '';
    if (text && title) {
      newRecieptForCurrentUser(title, text).then(function() {
        myRecieptsMenuButton.click();
      });
      messageInput.value = '';
      titleInput.value = '';
    }
  };

  // Bind menu buttons.
  
  myRecieptsMenuButton.onclick = function() {
    showSection(userRecieptsSection, myRecieptsMenuButton);
  };
  addButton.onclick = function() {
    showSection(addReciept);
    messageInput.value = '';
    titleInput.value = '';
    merchantInput.value = '';
    valueInput.value = '';
  };
}, false);
